# Responsive Portfolio Website Liz
## [Watch it on youtube](https://youtu.be/F2_6rFk-UC8)
### Responsive Portfolio Website Liz

- Responsive Personal Portfolio Website Using HTML CSS & JavaScript
- Contains several pages (About, Work & Contact)
- Includes a dark & light theme.
- Sending emails in the contact section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
